#!/bin/bash
# 大福玩具房 - 一键部署脚本
# 使用方法：在VPS上执行 bash deploy.sh

set -e  # 遇到错误立即退出

echo "🎉 开始部署大福玩具房..."

# 1. 更新系统
echo "📦 更新系统..."
apt-get update -y
apt-get upgrade -y

# 2. 安装Node.js
echo "🟢 安装Node.js..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
fi

# 显示Node版本
node --version
npm --version

# 3. 安装PM2（进程管理器）
echo "📊 安装PM2..."
npm install -g pm2

# 4. 创建项目目录
echo "📁 创建项目目录..."
mkdir -p /var/www/dafu-toy-room
cd /var/www/dafu-toy-room

# 5. 检查是否有上传的压缩包
if [ -f "/root/dafu-toy-room.tar.gz" ]; then
    echo "📦 找到压缩包，开始解压..."
    tar -xzvf /root/dafu-toy-room.tar.gz -C /var/www/dafu-toy-room
    rm /root/dafu-toy-room.tar.gz
elif [ -f "/home/dafu-toy-room.tar.gz" ]; then
    echo "📦 找到压缩包，开始解压..."
    tar -xzvf /home/dafu-toy-room.tar.gz -C /var/www/dafu-toy-room
    rm /home/dafu-toy-room.tar.gz
else
    echo "❌ 错误：未找到 dafu-toy-room.tar.gz 压缩包"
    echo "请先上传压缩包到 /root/ 或 /home/ 目录"
    exit 1
fi

# 6. 设置防火墙（如果安装了ufw）
if command -v ufw &> /dev/null; then
    echo "🔥 配置防火墙..."
    ufw allow 3000/tcp
    ufw allow 80/tcp
    ufw allow 443/tcp
fi

# 7. 启动应用
echo "🚀 启动应用..."
pm2 stop dafu-toy-room 2>/dev/null || true
pm2 start server.js --name "dafu-toy-room"

# 8. 设置开机自启
echo "⚙️ 设置开机自启..."
pm2 save
pm2 startup systemd -u root --hp /root

# 9. 显示完成信息
echo ""
echo "=========================================="
echo "✅ 部署完成！"
echo "=========================================="
echo ""
echo "🌐 网站地址："
echo "   http://$(curl -s ifconfig.me):3000"
echo ""
echo "📊 管理命令："
echo "   pm2 status          - 查看运行状态"
echo "   pm2 logs            - 查看日志"
echo "   pm2 restart dafu-toy-room  - 重启应用"
echo "   pm2 stop dafu-toy-room     - 停止应用"
echo ""
echo "📁 项目目录：/var/www/dafu-toy-room"
echo ""
echo "⚠️  重要提示："
echo "   1. 请确保防火墙已开放3000端口"
echo "   2. 如需使用AI聊天功能，请配置API密钥"
echo "   3. 建议配置Nginx反向代理和SSL证书"
echo ""
